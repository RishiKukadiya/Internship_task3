create database Ecommerce;
use Ecommerce;
select * from `e-commerce_data`;

# SQL Task Questions
#1. Basic Queries
#Q1: List the first 10 transactions with their invoice numbers, stock codes, descriptions, and quantities.
select invoiceno,StockCode,Description,quantity from `e-commerce_data`
limit 10;


#Q2: Retrieve all transactions where the quantity is greater than 100.​
select * from `e-commerce_data`
where quantity>100;



#2. Filtering and Sorting
#Q3: Find all transactions for the product "WHITE HANGING HEART T-LIGHT HOLDER".
 select * from `e-commerce_data` 
 where description='WHITE HANGING HEART T-LIGHT HOLDER';
 
 
 
 
#Q4: List the top 5 countries by the number of transactions,sorted in descending order.​
select COUNTRY,count(distinct invoiceno)as No_transactions from `e-commerce_data`
group by country
order by No_transactions desc
limit 5;



#3. Aggregations and Grouping

#Q5: Calculate the total quantity sold for each product.
select Description,sum(quantity) as total_quantity from `e-commerce_data`
group by description;






#Q6: Determine the average unit price per country.​
select country,round(avg(unitprice),2) as Avg_unit_Price
from `e-commerce_data`
group by country;

#4. Joins and Subqueries
#Q7: Identify customers who have purchased more than 10 different products.
select customerid,count(distinct stockcode) as diffrenct_products
from `e-commerce_data`
group by customerid
having diffrenct_products>10
order by  diffrenct_products desc;

#Q8: Find the top 5 products with the highest total sales revenue.​
select description,round((quantity*unitprice)) as total_revanue
from `e-commerce_data`
order by total_revanue desc
limit 5;

#5. Views and Indexing

#Q9: Create a view that shows the total sales per customer
select * from `e-commerce_data`;
CREATE VIEW CustomerTotalSales AS
SELECT CustomerID,SUM(Quantity * UnitPrice) AS TotalSales
FROM `e-commerce_data`
GROUP BY CustomerID;
-- use of view table
SELECT * FROM CustomerTotalSales
ORDER BY TotalSales DESC;


#Q10: Using a CTE, find the total revenue per customer and list only those customers who have spent more than ₹1000.
 with customerRevanue as (
select CustomerID,round(sum(quantity*unitprice),2) as total_revanue
from `e-commerce_data`
group by customerid
 )
 select * from customerRevanue
 where total_revanue>1000;
 





